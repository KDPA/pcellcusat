<?php
 include 'headerprofile.php';
error_reporting(E_ALL ^ E_DEPRECATED);
session_start();

if($_POST)
{

$course=$_POST['course'];
$regno=$_POST['regno'];
	include 'db.php';
	
	if($course=="UG")
	{
		
		$query = mysql_query("UPDATE ug_master SET reg='reg' where regno='$regno'");
		
		$result = ($query); 
		if( $result )
		{
			echo"the profile is registered";
		}
		else
		{
       echo "Query Failed";
		}
	}
	else if($course=="PG")
	{
		
		$query = mysql_query("UPDATE pg_master SET reg='reg' where regno='$regno'");
		$result = ($query); 
		if( $result )
		{
			echo"the profile is registered";
		}
		else
		{
         echo "Query Failed";
		}
		
	}
		
		
		mysql_close();
		
			
		 
}
else
{
echo	"acess denied";
}
include 'footer.php';
?>
