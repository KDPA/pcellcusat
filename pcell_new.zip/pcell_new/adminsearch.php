<html>
<head>
<?php include'headerprofile.php';?>
</head>

<body>


<u><h1 style='text-align:center;margin-top:-100px;'>STUDENT DETAILS</h1></u>
<center>
<form method="GET" action="adminsearch.php">

	<input type="text" name="search" placeholder="Search by email and regno">
	<input type="submit" name="submit" value="search database">

</form>
 
</center>
<hr />
<u>Results:</u>&nbsp

<?php

session_start();
error_reporting(E_ALL ^ E_DEPRECATED);


if(isset($_REQUEST['submit'])) {

	$search = $_GET['search'];
	$terms = explode(" ", $search);
	$query = "SELECT * FROM ug_master WHERE ";
	
	$i=0;
	foreach($terms as $each){		
		$i++;
		if($i==1){
			$query .= "concat_ws('',regno,email) LIKE '%$each%' ";
		}else{
			$query .= "OR concat_ws('',regno,email) LIKE '%$each%' ";
		}
	}
	
	include 'db.php';
	
	$query = mysql_query($query);
	$num = mysql_num_rows($query);
	
	if($num > 0 && $search!="")
	{
	
		echo "$num result(s) found for <b>$search</b>!";
	
		while($row = mysql_fetch_assoc($query))
		{
				$dname=$row['name'];
				$dreg=$row['regno'];
				$dcaste=$row['caste'];
				$demail=$row['email'];
				$dmname=$row['mname'];
				$dfname=$row['fname'];
				$dbirth=$row['religion'];
				$dno=$row['mnumber'];
				$marks1=$row['marks_obtained_s1'];
				$marks2=$row['total_marks_s1'];
				$dgpa1=$row['gpa_s1'];
				$dcredit1=$row['credit_s1'];
				$dblk1=$row['backlog_s1'];
				
		
		
			echo "
			<html>
			<body>
			<table style = 'color :#898989;padding:20px;align:center;float :center;margin-top:0px;margin-left :470px;font-size:20px;font-family:;'>
			<tr ><td style ='padding:5px; margin:0px;'>Name:-</td><td>$dname</td></tr>
			<tr><td style ='padding:5px; margin:0px;'>Registration Number:-</td><td>$dreg</td></tr>
			<tr ><td style ='padding:5px; margin:0px;'>Email Id:-</td><td>$demail</td></tr>
			<tr><td  style ='padding:5px; margin:px;'>Mother Name:-</td><td>$dmname</td></tr>
			<tr><td style ='padding:5px; margin:0px;'>Father Name:-</td><td>$dfname</td></tr>
			<tr><td style ='padding:5px; margin:0px;'>Total Marks:-</td><td>$marks1</td></tr>
			<tr><td style ='padding:5px; margin:0px;'>Marks Obtained:-</td><td>$marks2</td></tr>
			<tr><td style ='padding:5px; margin:0px;'>s1_gpa:-</td><td>$dgpa1</td></tr>
			<tr><td style ='padding:5px; margin:0px;'>s1_credit:-</td><td>$dcredit1</td></tr>
			<tr><td style ='padding:5px; margin:0px;'>s1_baklog:-</td><td>$dblk1</td></tr>
			</table>	
			</body>
			</html>";
		
		}
	
	} else {
	
		echo "No results found!";
	
	}

	mysql_close();

} else {

	echo "Please type any word...";

}



?>
<?php include'footer.php';?>
</body>


</html>