
<?php
session_start();

error_reporting(E_ALL ^ E_DEPRECATED);

if($_POST)
{
	

   $pass=$_post['opass'];
   $pass1 = $_POST['pass1'];
	$pass2 = $_POST['pass2'];
	
	

	if($pass1==$pass2)
	{
		
	include 'db.php';
	
	mysql_query("UPDATE admin_sign SET password = '$pass1' WHERE id='".$_SESSION['id']."'");
		echo"Your Password is updataed";
		
	 	mysql_close();
		
		
		
		
		
		//cs start//-----------------------------------------------------------------------------------------------------------
		
	}
	else
	{
		echo"Both password is not same";
		}
	
	
	
}
else{
	echo "Access Denied";
    exit;
}

?>