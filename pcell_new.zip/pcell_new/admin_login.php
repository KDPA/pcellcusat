<html>
<head>
<title> sign in </title>
<style type="text/css">
body {
background-color: #ffffe6;
color: #5a5656;
font-family: 'Open Sans', Arial, Helvetica, sans-serif;
font-size: 16px;
line-height: 1.5em;
}

h1 { font-size: 1em; }
h1, p {
margin-bottom: 12px;
}
strong {
font-weight: bold;
}
.uppercase { text-transform: uppercase; }

form fieldset input[type="text"], input[type="password"],input[type="text"],input[type="text"],input[type="number"],input[type="number"],input[type="text"],input[type="text"] {
background-color: #e5e5e5;
border: none;
border-radius: 3px;

color: #5a5656;
font-family: 'Open Sans', Arial, Helvetica, sans-serif;
font-size: 14px;
height: 50px;
outline: none;
padding: 0px 10px;
width: 280px;

}


	
	
registration{
	position:fixed;
	top:0px;
}





</style>
<body>
<?php include 'header.php';?>
<div id="registration"><strong>ADMIN LOGIN</strong></div>
<fieldset>
<form method="post"  action="admin_logcode.php" >
<table width="45%">
<tr><td width="70%">Userid: </td><td> <input type="text" placeholder="Userid" name="id" required value=""></p>
<tr><td width="70%">Password:</td><td> <input type="password"  placeholder="Password"  name="password" required value=""></p>
</table>
<p><STRONG><input   type="submit" name="submit" value="PLEASE CONTINUE"></STRONG></p>
</fieldset>
<?php include 'footer.php';?>
</body>
</html>



