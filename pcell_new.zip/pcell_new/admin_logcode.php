<?php
session_start();
error_reporting(E_ALL ^ E_DEPRECATED);
if($_POST)
{
	

$_SESSION['id'] = $_POST['id'];
$_SESSION['password'] = $_POST['password'];



if($_SESSION['id'] && $_SESSION['password'] )
{
	include 'db.php';
	$query = mysql_query("SELECT * FROM admin_sign	where id='".$_SESSION['id']."'");
	$row = mysql_num_rows($query);
	
	if($row !=0)
	{
		while($row=mysql_fetch_assoc($query))
		{
				$did=$row['id'];
				$dpass=$row['password'];
				
		}
			if($_SESSION['id']==$did)
			{
					if($_SESSION['password']==$dpass)
					{
						?>
							
<html>
<head>
<title> admin profile </title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css">
<style type="text/css">
body {
background-color: #ffffe6;
color: #5a5656;
font-family: 'Open Sans', Arial, Helvetica, sans-serif;
font-size: 16px;
line-height: 1.5em;
}

h1 { font-size: 1em; 
text-decoration:underline}
h1, p {
margin-bottom: 12px;
}
strong {
font-weight: bold;
}
.uppercase { text-transform: uppercase; }
h2{
	text-decoration:underline;
}

</style>


<body>
<?php include 'headerprofile.php';?>
<center>
<h2>ADMINSTRATOR PAGE</h2>
</br></br>
<h2>Recent Registration</h2>
</center>
<p>
<div class="w3-responsive">
<table class="w3-table-all">

<tr><td><form method="post"  action="ug_adminreg.php">
<input type="submit" name="ug" value="New Registratired UG Student" ></form></td>
</form>

<tr><td><form method="post"  action="pg_adminreg.php">
<input type="submit" name="ug" value="New Registratired PG Student" ></form></td>
</form>
</tr>
</table>
</br>
</br>
</div>

<h2>Placement Cell Head</h2></br>
<div style="margin-left:100px;">
<h3>Dr.James Varghese</h3>

Faculty In-charge</br>
Training and Placement Cell</br>
School of Engineering</br>
Cochin University Science And Technology</br>
Cochin-682022</br>
Kerala,India</br>
Mobile:+91 9495672695</br>
Placement office (Ph) 0484 - 2862400 , 2577794</br>
email: cusat.p [at]gmail.com , cpo[at]cusat.ac.in</br>
</div>
<?php include 'footer.php';?>
</body>

</html>
<?php

							 
					}
					else{
						echo"Your password is incorrect";
					}
			}
				else{
					echo "your id is incorrect";
				}
	}
	else{
		echo "Not regesterd yet";
	}
}
else
{
	echo "id is not filled";
}}
else{
	echo "Access DEnied";
	exit;
}
?>
